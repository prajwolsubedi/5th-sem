<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>validating form field and inserting in database</h2>
    <?php
        if(isset($_POST['submit'])){
            if(empty($_POST['uname'])||!isset($_POST['gender'])||empty($_POST['age'])|| !isset($_POST['chk'])){
                echo "please select all the field";
            }else{
                include "conn.php";
                $uname=$_POST['uname'];
                $gen = $_POST['gender'];
                $age = $_POST['age'];
	// $hobby = $_POST['chk'];
	// $hobby_str = implode(",",$hobby);
                //inserting into db
                $sql_insert="INSERT INTO tbl_final(username,gender,age,hobby) VALUES ('$uname','$gen','$age','dancing')";
                $sql_insert_query = mysqli_query($conn,$sql_insert);
                if($sql_insert_query){
                    echo "inserted";
                   header("Location: dis.php");

                }else{
                    echo"not inserted";
                }
            }
        }else{
            echo "error in submit";
        }
?>  
</body>
</html>
