<?php
// Start the session
session_start();

// Check if the user clicked the "Submit" button
if(isset($_POST['submit'])) {

  // Get the form data
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Check if the username and password are correct
  if($username == 'roshni' && $password == 'password') {

    // Set a session variable
    $_SESSION['loggedin'] = true;

    // Set a cookie that expires in 1 hour
    setcookie('username', $username, time()+3600);

    // Redirect the user to the action
    header('Location: action.php');
    exit();

  } else {
    // Display an error message
    echo "Invalid username or password";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
</head>
<body>
  <h1>Login</h1>
  <form method="POST">
    <label>Username:</label><br>
    <input type="text" name="username"><br>
    <label>Password:</label><br>
    <input type="password" name="password"><br>
    <br>
    <input type="submit" name="submit" value="Login">
  </form>
</body>
</html>
