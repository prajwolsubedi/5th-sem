<?php
include "conn.php";
if(isset($_POST['submit'])){
    if(empty($_POST['id'])||empty($_POST['uname'])||!isset($_POST['gender'])||empty($_POST['age'])){
        echo "please select all the field";
    }else{
        $id=$_POST['id'];
        $update_username=$_POST['uname'];
        $update_gender=$_POST['gender'];
        $update_age=$_POST['age'];
//  $update_hobby=$_POST['chk'];
// $hobby_str = implode(",",$update_hobby); //converting into string
$sql_update="UPDATE tbl_final SET username='$update_username',gender='$update_gender',age='$update_age',hobby='dancing' Where id=$id";
        $sql_update_query=mysqli_query($conn,$sql_update);
        if($sql_update_query){
            echo "record updated";
            header("Location: dis.php");
        }else{
            echo "record not updated";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>insert id and info of a person that you want to updata</h2>
    <form action="" method="POST">
    <label>Id:</label><input type="number" name="id"/><br/>
    <label>Username</label><input type="text" name="uname"/><br/>
    <label>Gender: </label><input type="radio" name="gender" value="male"/>Male &nbsp;&nbsp;
    <input type="radio" name="gender" value="female"/>Fe-Male <br/>
    <label>Age</label><input type="number" name="age"/><br/>
<label>Hobby:</label><input type="checkbox" name="chk[]" value="swimming"/>Swimming &nbsp;
    <input type="checkbox" name="chk[]" value="dancing"/>Dancing &nbsp;
    <input type="checkbox" name="chk[]" value="singing"/>Singing &nbsp;
    <br/>
    <input type="submit" name="submit" value="submit"/>
    </form>
</body>
</html>
