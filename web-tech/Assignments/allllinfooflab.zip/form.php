<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Document</title>
</head>
<body>
<h2> making form for Insert delete, display and update</h2>
<form action="val1.php" method="POST">
<label>Username</label><input type="text" name="uname"/><br/>
<label>Gender: </label><input type="radio" name="gender" value="male"/>Male &nbsp;&nbsp;
<input type="radio" name="gender" value="female"/>Female <br/>
<label>Age</label><input type="number" name="age"/><br/>
<label>Hobby:</label><input type="checkbox" name="chk[]" value="swimming"/>Swimming &nbsp;
<input type="checkbox" name="chk[]" value="dancing"/>Dancing &nbsp;
<input type="checkbox" name="chk[]" value="singing"/>Singing &nbsp;
<br/>
<input type="submit" name="submit" value="submit"/>
</form>
</body>
</html>