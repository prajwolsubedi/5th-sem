<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>

    <form method="post">
        Enter first number:
        <input type="number" name="var1"/><br><br>
        Enter second number:
        <input type="number" name="var2"/><br><br>
        <input type="submit" name="submit" value="sum">
    </form>
</head>
<body>
    <?php
    //1. operators
    // sum of digits of var1
    if(isset($_POST['submit'])) {
        $var1=$_POST['var1'];
        $digits_sum=0;
        while($var1>0)
        {
            $num=$var1%10;
            $digits_sum=$digits_sum+$num;
            $var1=$var1/10;
        }
        echo"sum of digits is ".$digits_sum."<br><br><br>";
    
    }
    //2. loop
    //program to print table of number
    if(isset($_POST['submit'])) {

            $var1=$_POST['var1'];
            echo"The table of number ".$var1." is: "."<br>";
            for($i=1;$i<=10;$i++)
            {
                echo $var1*$i."<br>";
                
            }
            echo"<br><br>";
    }

    //3. Array
    $cars = array("Volvo", "BMW", "Toyota");
    echo "I like " . $cars[0] . ", " . $cars[1] . " and " . $cars[2] . ".";
    ?>

    

</html>