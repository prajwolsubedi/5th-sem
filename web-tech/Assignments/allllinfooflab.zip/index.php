 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>

    <form method="post">
        Enter first number:
        <input type="number" name="var1"/><br><br>
        Enter second number:
        <input type="number" name="var2"/><br><br>
        <input type="submit" name="submit" value="sum">
    </form>
</head>
<body>
    
    <?php
    //sum
    if(isset($_POST['submit']))  {
        $var1=$_POST['var1'];
        $var2=$_POST['var2'];
        $sum=$var1+$var2;
        echo"<br><br>"."The sum of numbers is: ".$sum."<br><br><br>";
        echo"<br>";

    }

    // sum of digits of var1
    if(isset($_POST['submit'])) {
    $var1=$_POST['var1'];
    $digits_sum=0;
    while($var1>0)
    {
        $num=$var1%10;
        $digits_sum=$digits_sum+$num;
        $var1=$var1/10;
    }
    echo"sum of digits is ".$digits_sum."<br><br><br>";

    }
    

    //check wheather a number is even or odd
    if(isset($_POST['submit'])) {
        $var1=$_POST['var1'];
        if($var1%2==0)
        {
            echo"number".$var1." is even "."<br><br><br>";

        }
        else{
            echo"number ".$var1." is odd"."<br><br><br>";
        }
    }

    //check weather a number is prime or not
    if(isset($_POST['submit'])) {
        $var1=$_POST['var1'];
        $flag=0;
        for($i=2;$i<$var1/2;$i++)
        {
            if($var1%$i==0)
            {
                
                $flag++;
            }
            
            
        }
        if($flag>0)
        {
            printf("Number".$var1."is composite"."<br><br>");
        }
        else{
            printf("number".$var1." is prime"."<br><br>");
        }
    }

    //program to print table of number

   
    if(isset($_POST['submit'])) {

        $var1=$_POST['var1'];
        echo"The table of number ".$var1." is: "."<br>";
        for($i=1;$i<=10;$i++)
        {
            echo $var1*$i."<br>";
            
        }
        echo"<br><br>";
    }

    //program to check wheather the number is palindrome or not
    if(isset($_POST['submit'])) {

        $var1=$_POST['var1'];
        //reverse the string
       function palindrome($n)
         {
            $sum=0;
            while(floor($n)>0)
            {
                $rem=$n%10;
                $sum=$sum*10+$rem;
                $n=$n/10;
            }
            echo"reverse".$sum."<br><br><br>";
            return $sum;
        }
        $num=palindrome($var1);
        if($num==$var1)
        {
            echo"The number".$var1." is palindrome"."<br><br>";
        }
        else{
            echo"The number".$var1. "is not palindrome"."<br><br>";
        }
    }
?>
<?php  
$alpha = range('A', 'Z');  
for($i=0; $i<5; $i++){   
  for($j=5; $j>$i; $j--){  
    echo $alpha[$i];  
    }  
    echo "<br>";  
}  
echo"<br><br><br>";
for($i=1;$i<10;$i++)
{
    for($j=0;$j<$i;$j++)
    {
        echo $alpha[$j];
    }
    echo "<br>";
}

//star traingle
for($i=1;$i<=5;$i++)
{
    for($j=0;$j<$i;$j++){
        echo"*";
    }
    echo"<br>";
}
?>  

    
</body>
</html>