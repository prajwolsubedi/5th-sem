<?php
$servername="localhost";
$hostusername="root";
$hostpassword="";
$db="db_final";
$conn = mysqli_connect($servername,$hostusername,$hostpassword,$db);
if(!$conn){
            die("error in connection->".mysqli_connect_error());
}else{
    echo "Connected to db";
}
?>
