<?php
    include "conn.php";
    if(isset($_POST['submit'])){
        if(empty($_POST['id'])){
            echo"select id you want to delete";
        }else{$del_id = $_POST['id'];
            $sql_delete = "DELETE FROM tbl_final WHERE id=$del_id";
            $sql_del_execute = mysqli_query($conn,$sql_delete);
            if($sql_del_execute){
                echo "<br/>record deleted";
                header ("location: dis.php");
            }else{
                echo "record not deleted";
            }
    
            }
        }
        
    else{
        echo "errpr";
    }
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>insert id of person of which u want to delete record</h2>
    <form action="" method="POST">
    <label>id<label><input type="number" name="id"/><br/>
    <input type = "submit" name="submit" value="delete"/>
    </form>
</body>
</html>

