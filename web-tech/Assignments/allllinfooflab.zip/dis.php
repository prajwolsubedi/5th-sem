<?php
include "conn.php";
$sql_display= "SELECT * From tbl_final"; //to fetch all info
$sql_display_single = "SELECT * FROM tbl_final where id=1";//display single info
$sql_display_name = "SELECT * FROM tbl_final where username='Arju'";//display by name
$sql_display_gender="SELECT * From tbl_final where gender='female'";//display by gender
$sql_display_age = "SELECT * From tbl_final where age='20'";//display by age
$sql_display_execute=mysqli_query($conn,$sql_display);

if($sql_display_execute){
    $numberofrecord = mysqli_num_rows($sql_display_execute); //fetch no. of record form table
    echo "<br/>$numberofrecord";
    echo "<table border=1px;>";
    echo "<tr>";
    echo "<th>id</th>";
    echo "<th>username</th>";
    echo "<th>gender</th>";
    echo "<th>age</th>";
    echo "<th>hobby</th>";
    echo "<th>Update</th>";
    echo "<th>Delete</th>";
    echo "</tr>";

    while($row=mysqli_fetch_assoc($sql_display_execute)){
        $id=$row['id'];
        $username = $row['username'];
        $gender = $row['gender'];
        $age = $row['age'];
        $hobby = $row['hobby'];
        //echo "your id is $id";
        echo "<tr>";
        echo "<td>$id</td>";
        echo "<td>$username</td>";
        echo "<td>$gender</td>";
        echo "<td>$age</td>";
        echo "<td>$hobby</td>";
        echo "<td><a href='update.php'>Update</a></td>";
        echo "<td><a href='del.php'>Delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>
